How To Use

LiveStreamer MUST be installed for this to work
Before running this program, install LiveStreamer via the folder indicated

Please note, when you press the "X" on the program (Exit)
It does not close the window, it simply minimizes to your tray.
To close or re-open the window right click on the icon.

After finding a stream you would like to watch/save
Navigate to the stream via Live Streams tab and press Ctrl+`

This will copy the link of the stream to your clipboard.
A message will appear verifying the link.

After you have the link saved to your clipboard go to the tab Stream Input
Paste the URL in the box and select your quality you want.

After doing so, select if you want to save to favorites or not.

After all is done, press "Start Stream"

If you saved it to favorites it will ask you for a name that you want
to use for that specific stream. You can launch the stream now if you want.

The Favorites tab has two parts, an online and offline section.
Each time you press "Refresh" it will update the list accordingly.
The list will not autoupdate when a streamer goes live.
This is to reduce bandwith use.